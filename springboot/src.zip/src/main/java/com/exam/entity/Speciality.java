package com.exam.entity;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

@Data
public class Speciality {
    private String collegeId;
    private String speciality;
    private String collegeName;
}
