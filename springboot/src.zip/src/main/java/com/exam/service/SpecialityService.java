package com.exam.service;

import com.exam.entity.Speciality;

import java.util.List;

public interface SpecialityService {
    List<Speciality> findAll();
}
